package com.money;

public class BankController {
	
	public synchronized void deposit(String aNo, double amt)
	{
		for(User x: Storage.ulist)
		{
			if(x.getAcc_no().equals(aNo))
			{
				x.setBal(x.getBal()+amt);
				
				Transaction t = new Transaction();
				t.setType("credit");
				t.setCurr_Bal(x.getBal());
				x.getTrans().add(t);
			}
		}
	}
	
	public synchronized void withDraw(String aNo, double amt)
	{
		for(User x: Storage.ulist)
		{
			if(x.getAcc_no().equals(aNo) && x.getBal()>=amt)
			{
				x.setBal(x.getBal()-amt);
				
				Transaction t = new Transaction();
				t.setType("withdraw");
				t.setCurr_Bal(x.getBal());
				x.getTrans().add(t);
			}
			else
			{
				System.out.println("In-sufficient Balance");
			}
		}
			
	}

	
	public void checkBalance(String aNo)
	{
		for(User x: Storage.ulist)
		{
			if(x.getAcc_no().equals(aNo))
			{
				System.out.println(x.getBal());
			}
		}
	}
	public void transactionHistory(String aNo)
	{
		for(User x: Storage.ulist)
		{
			if(x.getAcc_no().equals(aNo))
			{
				for (Transaction tran: x.getTrans())
				   System.out.println(tran.getType()+ " Date : "+tran.getDate()+" "+"balance :" + tran.getCurr_Bal());
			}
		}
	}
	
}
