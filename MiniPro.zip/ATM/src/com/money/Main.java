package com.money;

public class Main extends Thread{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//adding users to list
		User u1 = new User("Raju", "12345");
		Storage.ulist.add(u1);
		BankController bc = new BankController();
		
		
		
		Thread t1= new Thread(new Runnable (){
		    public void run(){
		    	
		    	bc.deposit("12345", 1000);
		    	bc.withDraw("12345", 500);
		    	System.out.println(currentThread().getName());
				bc.checkBalance("12345");

		    }
		});
		
		Thread t2= new Thread(new Runnable (){
		    public void run(){
		    	
		    	bc.deposit("12345", 1000);
		    	bc.withDraw("12345", 900);
		    	System.out.println(currentThread().getName());
				bc.checkBalance("12345");
				bc.transactionHistory("12345");
		    }
		});
		
		
		
		t1.start();
		t2.start();
		
		
	}

}
