package com.money;

import java.util.ArrayList;
import java.util.List;

public class Storage {
	
	public static List<User> ulist= new ArrayList<>(); 

}
