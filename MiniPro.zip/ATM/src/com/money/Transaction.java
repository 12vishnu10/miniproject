package com.money;

import java.util.Date;

public class Transaction {
	
	private Date date;
	private String type;
	private double curr_Bal;
	
	public Date getDate() {
		return date;
	}
	public Transaction() {
		super();
		this.date = new Date();
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getCurr_Bal() {
		return curr_Bal;
	}
	public void setCurr_Bal(double curr_Bal) {
		this.curr_Bal = curr_Bal;
	}
	
	

}
