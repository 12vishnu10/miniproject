package com.money;

import java.util.ArrayList;
import java.util.List;

public class User {
	
	private String name;
	private String acc_no;
	private double bal;
	private List<Transaction> trans;
	
	
	public User(String name, String acc_no) {
		super();
		this.name = name;
		this.acc_no = acc_no;
		this.bal = 0;
		this.trans = new ArrayList<>();
	}
	public User() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(String acc_no) {
		this.acc_no = acc_no;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public List<Transaction> getTrans() {
		return trans;
	}
	public void setTrans(List<Transaction> trans) {
		this.trans = trans;
	}
	
	

}
