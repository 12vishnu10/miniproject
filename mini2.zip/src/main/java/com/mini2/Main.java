package com.mini2;

import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws ClassNotFoundException {
		dbConnection d = new dbConnection();
		d.Conectionn();

		while (true) {
			System.out.println("Choose the following..");
			System.out.println("1.AddEmp\n2.EditEmp\n3.ManagerHirarichy\n4.Resign\n5.status\n6.Exit");
			int n = sc.nextInt();

			switch (n) {

			case 1:
				addEmployee e = new addEmployee();
				e.addEmp();
				break;

			case 2:
				editEmployee e1 = new editEmployee();
				e1.editEmp();
				break;

			case 3:
				managerHi mH = new managerHi();
				mH.mView();
				break;

			case 4:
				eResign r = new eResign();
				r.reg();
				break;
			case 5:
				statusCheck s = new statusCheck();
				s.eStatus();
				break;
			case 6:
				System.exit(0);
				break;
			default:
				System.out.println("Enter a vaild choose");
				break;
			}

		}

	}

}