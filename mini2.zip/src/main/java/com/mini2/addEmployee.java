package com.mini2;

import java.sql.SQLException;
import java.util.Scanner;

public class addEmployee {
	Scanner sc = new Scanner(System.in);

	public void addEmp() {
		try {
			String sql = "insert into emp2"
					+ "(eId,eName,eManager,eProDate,eProName,eStatus,ePick,eDrop,eDependent) values"
					+ "(?,?,?,?,?,?,?,?,?);";

			dbConnection.ps = dbConnection.con.prepareStatement(sql);

			System.out.println("Enter EId");
			dbConnection.ps.setInt(1, sc.nextInt());

			System.out.println("Enter Name");
			dbConnection.ps.setString(2, sc.next());

			System.out.println("Enter Manager Name");
			dbConnection.ps.setString(3, sc.next());

			System.out.println("Enter Project Date");
			dbConnection.ps.setString(4, sc.next());

			System.out.println("Enter Project Name");
			dbConnection.ps.setString(5, sc.next());

			System.out.println("Enter Empoyee status");
			dbConnection.ps.setString(6, sc.next());

			System.out.println("Enter Pick Location");
			dbConnection.ps.setString(7, sc.next());

			System.out.println("Enter Drop Location");
			dbConnection.ps.setString(8, sc.next());

			System.out.println("Enter Dependent Name");
			dbConnection.ps.setString(9, sc.next());

			int k = dbConnection.ps.executeUpdate();

			if (k == 1) {
				System.out.println("Inserted Sucussfully");
			} else {
				System.out.println("Not inserted");
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}