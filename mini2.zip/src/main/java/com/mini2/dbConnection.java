package com.mini2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class dbConnection {

	public static PreparedStatement ps = null;
	public static Connection con = null;

	public void Conectionn() throws ClassNotFoundException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db2", "root", "Root123$");

			if (con != null) {
				System.out.println("Connected");
			} else {
				System.out.println("Not Connected");
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}
