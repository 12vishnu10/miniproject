package com.mini2;

import java.util.Scanner;

public class eResign {
	Scanner sc = new Scanner(System.in);

	public void reg() {

		try {
//			System.out.println("Enter Your id to show employee active/inactive");
//			String eId = Main.sc.next();

			statusCheck s = new statusCheck();
			s.eStatus();

			String sql11 = "update emp2 set eStatus=? where eId=?";

			dbConnection.ps = dbConnection.con.prepareStatement(sql11);

			dbConnection.ps.setString(1, "resigned");
			dbConnection.ps.setInt(2, s.id);
			int reg = dbConnection.ps.executeUpdate();
			if (reg == 1) {
				System.out.println("You are sucussfully regsined");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}