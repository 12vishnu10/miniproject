package com.mini2;

import java.sql.SQLException;
import java.util.Scanner;

public class editEmployee {

	static Scanner sc = new Scanner(System.in);

	public void editEmp() throws ClassNotFoundException {
		try {
			statusCheck s = new statusCheck();
			s.eStatus();

//			System.out.println("Enter your id to update details");
//			int etu=sc.nextInt();
			System.out.println("Please Enter the following details");

			String sql1 = "update emp2 set eName=?,eManager=?,eStatus=?,ePick=?,eDrop=?,eDependent=? where eId=?";

			dbConnection.ps = dbConnection.con.prepareStatement(sql1);

			System.out.println("Enter Name");
			dbConnection.ps.setString(1, sc.next());

			System.out.println("Enter Manager Name");
			dbConnection.ps.setString(2, sc.next());

			System.out.println("Enter Empoyee status");
			dbConnection.ps.setString(3, sc.next());

			System.out.println("Enter Pick Location");
			dbConnection.ps.setString(4, sc.next());

			System.out.println("Enter Drop Location");
			dbConnection.ps.setString(5, sc.next());

			System.out.println("Enter Dependent Name");
			dbConnection.ps.setString(6, sc.next());

			dbConnection.ps.setInt(7, s.id);

			int k = dbConnection.ps.executeUpdate();
			if (k == 1) {
				System.out.println("Data Updated Sucussfull");
			} else {
				System.out.println("Data Not Updated.. Enter a valid emp Id to update");
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}