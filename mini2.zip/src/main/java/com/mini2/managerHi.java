package com.mini2;

import java.sql.ResultSet;
import java.sql.SQLException;

public class managerHi {

	public void mView() throws ClassNotFoundException {
		try {
			int k = 0;
			System.out.println("Enter Your Name to show employess under you");
			String manName = Main.sc.next();

			String sql = "select * from emp2 where eManager=?";

			dbConnection.ps = dbConnection.con.prepareStatement(sql);
			dbConnection.ps.setString(1, manName);

			ResultSet rs = dbConnection.ps.executeQuery();

			while (rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(4) + " " + rs.getString(5)
						+ " " + rs.getString(6) + " " + rs.getString(7) + " " + rs.getString(8));
				k++;
			}

			if (k == 0) {
				System.out.println("No employees under " + manName);
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
	}

}