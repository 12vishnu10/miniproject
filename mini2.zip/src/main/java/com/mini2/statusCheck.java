package com.mini2;

import java.sql.ResultSet;
import java.util.Scanner;

public class statusCheck {

	static Scanner sc = new Scanner(System.in);
	static int id;

	public void eStatus() throws ClassNotFoundException {
		try {
			System.out.println("Enter you Id to continue");
			id = sc.nextInt();

			String sql = "select eStatus from emp2 where eId=?";
			dbConnection.ps = dbConnection.con.prepareStatement(sql);

			dbConnection.ps.setInt(1, id);
			ResultSet rs1 = dbConnection.ps.executeQuery();
			rs1.next();

			if ((rs1.getString(1)).equals("resigned")) {
				System.out.println("You are not the part of the organization\nYou don't have access");
				System.exit(0);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}